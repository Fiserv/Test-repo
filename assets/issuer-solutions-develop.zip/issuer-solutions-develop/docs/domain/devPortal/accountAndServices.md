# Accounts & Services

Processing and management of card accounts and payment services, such as ACH, check processing, payment receipt & posting, fees, etc.

**Who is it for:** Developers creating or integrating apps that need to tap into information about the financial institution accountholders’ statements and transaction activity that reside on the Fiserv Optis platform.

**How is it used:** Employ these APIs to retrieve transactions residing on cardholders’ statements as well as upcoming cycle to date activity.

**Potential uses:** Apps that provide a mobile or browser experience for customers to view their recent and historical transaction activity.

Begin the integration with following services within the Cards Accounts Management / Payments domain in API Explorer:

* [Alpha Search](../api/?type=post&path=/account/v4/alphaSearch)


## See Also
- [Customer Service](?path=docs/domain/customerService.md "Click to open")
- [Merchant Processing](?path=docs/domain/merchantProcessing.md "Click to open")
- [Payment](?path=docs/domain/payment.md "Click to open")
