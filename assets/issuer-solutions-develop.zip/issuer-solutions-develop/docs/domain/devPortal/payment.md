# Payment

Processing of cardholder initiated payments on their outstanding balances.

**Who is it for:** Developers creating or integrating apps that need to process a payment request on behalf of a customer.

**How is it used:** Employ these APIs to process and retrieve payment information applied to customers’ accounts.

**Potential uses:** Apps that provide a customer with a mobile or browser experience to provide a payment request to the Optis system.

Begin the integration with following services of Transaction Processing domain in API Explorer:
* [Right Time Payment](../api/?type=post&path=/payments/v2/autoPayments)
* [Payment History](../api/?type=post&path=/payments/v2/paymentHistory)
* [Payment Details](../api/?type=post&path=/payments/v2/paymentDetails)

## See Also
- [Account & Service](?path=docs/domain/accountAndService.md "Click to open")
- [Customer Service](?path=docs/domain/customerService.md "Click to open")
- [Merchant Processing](?path=docs/domain/merchantProcessing.md "Click to open")
