# Customer Service

Agency responsible for tracking customer's financial activity and assign a credit or risk score for every cardholder; Delinquent amount that was recovered from the cardholder

**Who is it for:** Developers creating or integrating apps that need to tap into information about the financial institution accountholders that resides on Fiserv core account processing platforms

**How is it used:** Employ these APIs to create or integrate applications that require the ability to define relationships between individual parties and accounts and determine which accounts an individual party can access

**Potential uses:** Apps that provide customized account access or consolidated views of accounts or family finance apps that help young people pursue their financial goals with oversight from trusted adults

Begin the integration with following services of Customer Management domain in API Explorer:
* [Active Registration](../api/?type=post&path=/ecsPayments/v2/activeRegistration)

## See Also
- [Account & Service](?path=docs/domain/accountAndService.md "Click to open")
- [Merchant Processing](?path=docs/domain/merchantProcessing.md "Click to open")
- [Payment](?path=docs/domain/payment.md "Click to open")
