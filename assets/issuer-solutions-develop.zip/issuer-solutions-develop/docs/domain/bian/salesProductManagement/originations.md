# Originations

Create new payment instruments for customers in real-time.

**Who is it for:** Developers managing applications that provide real-time opportunities for customers to obtain a new payment instrument.

**How is it used:** Employ these APIs to create new payment instruments in a real-time fashion to be used immediately.

**Potential uses:** Apps that allow customers who have an approved card application to order a new payment instrument in a real-time fashion.

Begin the integration with following services of the Originations domain in API Explorer:
* [Card Issuance](../api/?type=post&path=/account/cardIssuance)
* [Card Issuance Plastic](../api/?type=post&path=/account/cardIssuancePlastic)
* [Instant Issuance Detail](../api/?type=post&path=/account/instantIssuanceDetail)
* [Card Issuance Card Carrier](../api/?type=post&path=/customer/cardIssuanceCardCarrier)
* [Card Issuance Product](../api/?type=post&path=/customer/cardIssuanceProduct)
* [Pending Emboss](../api/?type=post&path=/customer/pendingEmboss)
* [Consumer Account Add](../api/?type=post&path=/debit/consumerAccountAdd)
* [Card Issuance Mail Code Update](../api/?type=post&path=/maintenance/cardIssuanceMailCodeUpdate)
* [Card Issuance Product Cancel](../api/?type=post&path=/maintenance/cardIssuanceProductCancel)
* [Card Issuance Rush Indicator Update](../api/?type=post&path=/maintenance/cardIssuanceRushIndicatorUpdate)
* [Card Issuance Tran Cancel](../api/?type=post&path=/maintenance/cardIssuanceTranCancel)
* [Custom New Account](../api/?type=post&path=/maintenance/customnewaccount)
* [Expanded New Account](../api/?type=post&path=/maintenance/expandedNewAccount)
* [Generate New Acct Number](../api/?type=post&path=/maintenance/generateNewAcctNumber)
* [Instant Issuance Emv Chip Add](../api/?type=post&path=/maintenance/instantIssuanceEmvChipAdd)
* [New Account](../api/?type=post&path=/maintenance/newAccount)

## See Also
- [Card Type](?path=docs/domain/bian/salesProductManagement/cardType.md "Click to open")
