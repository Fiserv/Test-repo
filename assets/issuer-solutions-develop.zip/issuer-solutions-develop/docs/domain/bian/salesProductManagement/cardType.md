# Card Type

Functions necessary to distinguish types of payment instruments.

**Who is it for:** Developers of applications that require knowledge of a particular type of payment instrument in order to create a divergent workflow.

**How is it used:** Employ these APIs for extracting or updating data that indicates the type of payment instrument in use.

**Potential uses:** Apps that span multiple segments of the payment industry.

Begin the integration with following services of the Card Type domain in API Explorer:

<!-- 
type: tab 
titles: Popular Services, Others
-->
* [Company Accounts](../api/?type=post&path=/account/v4/companyAccounts)
* [Debit Balance Retrieval](../api/?type=post&path=/debit/v1/debitBalanceRetrieval)
* [Clear Fund Balance Available Amount](../api/?type=post&path=/healthcare/v1/clearFundBalanceAvailableAmount)
* [Debit Summary](../api/?type=post&path=/debit/v1/debitSummary)
* [Multi Purse Balance Summary](../api/?type=post&path=/healthcare/v1/multiPurseBalanceSummary)
* [Update Balance Summary](../api/?type=post&path=/healthTransaction/v1/updateBalanceSummary)
* [Consumer Accounts](../api/?type=post&path=/debit/v1/consumerAccounts)
* [Company](../api/?type=post&path=/creditBureau/v1/company)
* [Primary Dda Balance Retrieval](../api/?type=post&path=/debit/v1/primaryDdaBalanceRetrieval)
* [Debit Dda Xref](../api/?type=post&path=/debit/v1/debitDdaXref)
* [Bulk Shipment Address Details](../api/?type=post&path=/commercialcard/v1/bulkShipmentAddressDetails)
* [Multi Purse Table Override](../api/?type=post&path=/healthcare/v1/multiPurseTableOverride)
* [Get By Date IVR Details](../api/?type=post&path=/healthTransaction/v1/getByDateIVRDetails)
* [Debit Open To Buy](../api/?type=post&path=/debit/v1/debitOpenToBuy)
* [Debit Dda Maintenance](../api/?type=post&path=/debit/v1/debitDdaMaintenance)
* [Cycle Statement Details](../api/?type=post&path=/healthTransaction/v1/cycleStatementDetails)
* [Company Add](../api/?type=post&path=/memos/v1/companyAdd)
* [Debit Dda Linked Accounts](../api/?type=post&path=/debit/v1/debitDdaLinkedAccounts)
* [Debit Balance Update](../api/?type=post&path=/debit/v1/debitBalanceUpdate)
* [Current Statement Details](../api/?type=post&path=/healthTransaction/v1/currentStatementDetails)
* [Update Commercial Card Account Info](../api/?type=post&path=/commercialCardUpdate/v1/updateCommercialCardAccountInfo)
* [Company Add](../api/?type=post&path=/commercialcard/v1/companyAdd)
* [Debit Dda Balance Update](../api/?type=post&path=/debit/v1/debitDdaBalanceUpdate)
* [Company Update](../api/?type=post&path=/commercialcard/v1/companyUpdate)
* [Custom Mcc Group List](../api/?type=post&path=/commercialcard/v1/customMccGroupList)
* [Company Auth Strategy Summary](../api/?type=post&path=/authorizations/v2/companyAuthStrategySummary)
* [Get Company Account Prefil Details](../api/?type=post&path=/commercialcard/v1/getCompanyAccountPrefilDetails)
* [Substantiation Update](../api/?type=post&path=/healthTransaction/v1/substantiationUpdate)

<!-- type: tab -->

* [Company Update](../api/?type=post&path=/memos/v1/companyUpdate)
* [Company Auth Strategy Detail](../api/?type=post&path=/authorizations/v2/companyAuthStrategyDetail)
* [Account Spending Limit Update](../api/?type=post&path=/commercialcard/v1/accountSpendingLimitUpdate)
* [Account Spending Limit Add](../api/?type=post&path=/commercialcard/v1/accountSpendingLimitAdd)
* [Company Delete](../api/?type=post&path=/memos/v1/companyDelete)
* [Company Auth Strategy Update](../api/?type=post&path=/authorizations/v2/companyAuthStrategyUpdate)
* [Account Day Hour Restrictions](../api/?type=post&path=/commercialcard/v1/accountDayHourRestrictions)
* [Account Day Hour Restrictions Add](../api/?type=post&path=/commercialcard/v1/accountDayHourRestrictionsAdd)
* [Account Vendor List Detail](../api/?type=post&path=/commercialcard/v1/accountVendorListDetail)
* [Add Company Driver](../api/?type=post&path=/commercialcard/v1/addCompanyDriver)
* [Add Company Spending Limit](../api/?type=post&path=/commercialcard/v1/addCompanySpendingLimit)
* [Add Company Vendor List](../api/?type=post&path=/commercialcard/v1/addCompanyVendorList)
* [Add Custom Mcc Group](../api/?type=post&path=/commercialcard/v1/addCustomMccGroup)
* [Add Fleet Group](../api/?type=post&path=/commercialcard/v1/addFleetGroup)
* [Assign Custom Mcc Group](../api/?type=post&path=/commercialcard/v1/assignCustomMccGroup)
* [Commercial Card Reporting Levels](../api/?type=post&path=/commercialcard/v1/commercialCardReportingLevels)
* [Company Account Prefill Add](../api/?type=post&path=/commercialcard/v1/companyAccountPrefillAdd)
* [Company Account Prefill Update](../api/?type=post&path=/commercialcard/v1/companyAccountPrefillUpdate)
* [Company Auth Param Detail](../api/?type=post&path=/commercialcard/v1/companyAuthParamDetail)
* [Company Cancel Propagations](../api/?type=post&path=/commercialcard/v1/companyCancelPropagations)
* [Company Description Add](../api/?type=post&path=/commercialcard/v1/companyDescriptionAdd)
* [Company Description Delete](../api/?type=post&path=/commercialcard/v1/companyDescriptionDelete)
* [Company Description Detail](../api/?type=post&path=/commercialcard/v1/companyDescriptionDetail)
* [Company Description Update](../api/?type=post&path=/commercialcard/v1/companyDescriptionUpdate)
* [Company Driver](../api/?type=post&path=/commercialcard/v1/companyDriver)
* [Company Fleet Group](../api/?type=post&path=/commercialcard/v1/companyFleetGroup)
* [Company Level Add](../api/?type=post&path=/commercialcard/v1/companyLevelAdd)
* [Company Level Detail](../api/?type=post&path=/commercialcard/v1/companyLevelDetail)
* [Company Pending Propagations](../api/?type=post&path=/commercialcard/v1/companyPendingPropagations)
* [Company Spending Limit Detail](../api/?type=post&path=/commercialcard/v1/companySpendingLimitDetail)
* [Company Vehicle](../api/?type=post&path=/commercialcard/v1/companyVehicle)
* [Company Vendor List Detail](../api/?type=post&path=/commercialcard/v1/companyVendorListDetail)
* [Custom Mcc Group Detail](../api/?type=post&path=/commercialcard/v1/customMccGroupDetail)
* [Delete Account Level Day Hour Restriction](../api/?type=post&path=/commercialcard/v1/deleteAccountLevelDayHourRestriction)
* [Delete Company Driver](../api/?type=post&path=/commercialcard/v1/deleteCompanyDriver)
* [Delete Company Vehicle](../api/?type=post&path=/commercialcard/v1/deleteCompanyVehicle)
* [Delete Custom Mcc Group](../api/?type=post&path=/commercialcard/v1/deleteCustomMccGroup)
* [Delete Fleet Group](../api/?type=post&path=/commercialcard/v1/deleteFleetGroup)
* [Delete Spending Limit Group](../api/?type=post&path=/commercialcard/v1/deleteSpendingLimitGroup)
* [Propagate Update](../api/?type=post&path=/commercialcard/v1/propagateUpdate)
* [Update Account Level Day Hour Restriction](../api/?type=post&path=/commercialcard/v1/updateAccountLevelDayHourRestriction)
* [Update Company Driver](../api/?type=post&path=/commercialcard/v1/updateCompanyDriver)
* [Update Custom Mcc Group](../api/?type=post&path=/commercialcard/v1/updateCustomMccGroup)
* [Update Fleet Group](../api/?type=post&path=/commercialcard/v1/updateFleetGroup)
* [Debit Dda Maintenance Update](../api/?type=post&path=/debit/v1/debitDdaMaintenanceUpdate)
* [Add Override Merchant Category Code](../api/?type=post&path=/healthcare/v1/addOverrideMerchantCategoryCode)
* [Carrier Claim](../api/?type=post&path=/healthcare/v1/carrierClaim)
* [Copay Add](../api/?type=post&path=/healthcare/v1/copayAdd)
* [Copay Delete](../api/?type=post&path=/healthcare/v1/copayDelete)
* [Delete Override Merchant Category Code](../api/?type=post&path=/healthcare/v1/deleteOverrideMerchantCategoryCode)
* [External Member Account](../api/?type=post&path=/healthcare/v1/externalMemberAccount)
* [Get Recurring Transaction](../api/?type=post&path=/healthcare/v1/getRecurringTransaction)
* [Hsa Enrollment Create](../api/?type=post&path=/healthcare/v1/hsaEnrollmentCreate)
* [Hsa Enrollment Delete](../api/?type=post&path=/healthcare/v1/hsaEnrollmentDelete)
* [Hsa Enrollment Transfer](../api/?type=post&path=/healthcare/v1/hsaEnrollmentTransfer)
* [Hsa Enrollment Update](../api/?type=post&path=/healthcare/v1/hsaEnrollmentUpdate)
* [Processing Partner](../api/?type=post&path=/healthcare/v1/processingPartner)
* [Recurring Transaction Add](../api/?type=post&path=/healthcare/v1/recurringTransactionAdd)
* [Recurring Transaction Delete](../api/?type=post&path=/healthcare/v1/recurringTransactionDelete)
* [Settlement Controls Add](../api/?type=post&path=/healthcare/v1/settlementControlsAdd)
* [Settlement Exclusions Add](../api/?type=post&path=/healthcare/v1/settlementExclusionsAdd)
* [Get Address Details](../api/?type=post&path=/healthTransaction/v1/getAddressDetails)
* [Get Cvv Cvc](../api/?type=post&path=/healthTransaction/v1/getCvvCvc)
* [Get External Account Info](../api/?type=post&path=/healthTransaction/v1/getExternalAccountInfo)
* [Security Queue](../api/?type=post&path=/healthTransaction/v1/securityQueue)

<!-- type: tab-end -->

## See Also
- [Originations](?path=docs/domain/bian/salesProductManagement/originations.md "Click to open")