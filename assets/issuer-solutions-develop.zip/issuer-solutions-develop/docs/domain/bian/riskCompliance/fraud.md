# Fraud

Manage fraudulent activity on a customer’s payment instrument.

**Who is it for:** Developers responsible for fraud detection and resolution products.

**How is it used:** Employ these APIs to mark a card and its transactional activity as fraudulent or potentially fraudulent.

**Potential uses:** Apps that investigate fraud on behalf of customers.

Begin the integration with following services of External Agencies domain in API Explorer:
* [Client Defined Fraud Queuing](../api/?type=post&path=/maintenance/v2/clientDefinedFraudQueuing)
* [Flag Fraudulent Authorization](../api/?type=post&path=/maintenance/v2/flagFraudulentAuthorization)
* [Fraud Behavior Type Update](../api/?type=post&path=/maintenance/v2/fraudBehaviorTypeUpdate)
* [Fraud Behavior Type 2 Update](../api/?type=post&path=/maintenance/v2/fraudBehaviorType2Update)
* [Fraud Behavior Type 3 Update](../api/?type=post&path=/maintenance/v2/fraudBehaviorType3Update)
* [Fraud Strategy Expiration Date Update](../api/?type=post&path=/maintenance/v2/fraudStrategyExpirationDateUpdate)
* [Fraud Strategy Identifier Update](../api/?type=post&path=/maintenance/v2/fraudStrategyIdentifierUpdate)
* [Fraud Suspend Strategy](../api/?type=post&path=/maintenance/v2/fraudSuspendStrategy)
* [Lost Stolen Separate Entity](../api/?type=post&path=/maintenance/v2/lostStolenSeparateEntity)
* [Review Fraudulent Transaction](../api/?type=post&path=/maintenance/v2/reviewFraudulentTransaction)
* [Get Lost Stolen Report](../api/?type=post&path=/healthTransaction/v1/getLostStolenReport)
* [Lost Stolen Separate Entity](../api/?type=post&path=/healthTransaction/v1/lostStolenSeparateEntity)
* [Security Details](../api/?type=post&path=/account/v4/securityDetails)
* [Security Report](../api/?type=post&path=/account/v4/securityReport)
* [Update Risk Score](../api/?type=post&path=/nonmonetary/v1/updateRiskScore)