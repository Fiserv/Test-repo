# Merchant Processing

The Merchant Processing domain consists of APIs used to create, maintain and retrieve data relevant to Processing Merchants on the Optis platform.

Financial Institutions may use these APIs to establish Processing Merchants used in the execution of monetary transactions.  Processing Merchant Numbers are used for monetary adjustments and manual authorizations.

**Who is it for:** Developers creating or integrating applications that process monetary adjustments and/or manual authorizations and need to establishing Processing Merchants.

**How is it used:** Once a set of Processing Merchants are established on the Optis platform, API calls that require a Processing Merchant may incorporate these merchants into their associated activity for monetary adjustments and manual authorizations.

**Potential uses:** Applications that post sales, reversals, payments, fees, credits, debits, etc. as monetary adjustments and those applications that wish to manually post merchandise sales or cash advances as authorizations use Processing Merchants to establish the appropriate reconciliation of the monetary to their merchant categorizations.

Begin the integration with following services of Merchant domain in API Explorer:

### Merchant

* [Merchant Block Criteria](../api/?type=post&path=/merchant/v1/merchantBlockCriteria)
* [Merchant Block Criteria Add](../api/?type=post&path=/merchant/v1/merchantBlockCriteriaAdd)
* [Merchant Block Criteria Delete](../api/?type=post&path=/merchant/v1/merchantBlockCriteriaDelete)
* [Merchant Block Criteria Update](../api/?type=post&path=/merchant/v1/merchantBlockCriteriaUpdate)
* [Merchant Blocked Entries](../api/?type=post&path=/merchant/v1/merchantBlockedEntries)
* [Merchant Blocked Entries Delete](../api/?type=post&path=/merchant/v1/merchantBlockedEntryDelete)
* [Merchant Blocked Entries Update](../api/?type=post&path=/merchant/v1/merchantBlockedEntryUpdate)
* [Merchant Block Exclusion](../api/?type=post&path=/merchant/v1/merchantBlockExclusion)
* [Merchant Block Exclusion Add](../api/?type=post&path=/merchant/v1/merchantBlockExclusionAdd)
* [Merchant Block Exclusion Delete](../api/?type=post&path=/merchant/v1/merchantBlockExclusionDelete)
* [Merchant Block Notification](../api/?type=post&path=/merchant/v1/merchantBlockNotification)
* [Merchant Block Notification Add](../api/?type=post&path=/merchant/v1/merchantBlockNotificationAdd)
* [Merchant Block Notification Delete](../api/?type=post&path=/merchant/v1/merchantBlockNotificationDelete)
* [Merchant Block Notification Update](../api/?type=post&path=/merchant/v1/merchantBlockNotificationUpdate)

### Merchant Views

* [CaidXrefAdd](../api/?type=post&path=/merchantViews/v4/caidXrefAdd)
* [caidXrefDelete](../api/?type=post&path=/merchantViews/v4/caidXrefDelete)
* [caidXrefDetail](../api/?type=post&path=/merchantViews/v4/caidXrefDetail)
* [caidXrefUpdate](../api/?type=post&path=/merchantViews/v4/caidXrefUpdate)
* [etcOpenBatchDisplay](../api/?type=post&path=/merchantViews/v4/etcOpenBatchDisplay)
* [Merchant Card Type Transaction](../api/?type=post&path=/merchantViews/v4/merchantCardTypeTransaction)
* [Merchant Memo](../api/?type=post&path=/merchantViews/v4/merchantMemo)
* [Merchant Program Detail](../api/?type=post&path=/merchantViews/v4/merchantProgramDetail)
* [Merchant Program Summary And Detail](../api/?type=post&path=/merchantViews/v4/merchantProgramSummaryAndDetail)


## See Also
- [Cards Accounts Management / Payments](?path=docs/domain/bian/cardsAccountsManagementPayments.md "Click to open")
- [Channels Digital](?path=docs/domain/bian/channelsDigital.md "Click to open")
- [Collections](?path=docs/domain/bian/collections.md "Click to open")
- [Customer Management](?path=docs/domain/bian/customerManagement.md "Click to open")
- [Installment Loans](?path=docs/domain/bian/installmentLoans.md "Click to open")
- [Loyalty Programs](?path=docs/domain/bian/loyaltyPrograms.md "Click to open")
- [Servicing](?path=docs/domain/bian/servicing.md "Click to open")
