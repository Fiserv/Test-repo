# Collections

Delinquent balance collections, outbound call, agency reporting, etc.

**Who is it for:** Developers creating or integrating apps that need to tap into information about the financial institution accountholders that resides on Fiserv core account processing platforms.

**How is it used:** Employ these APIs to create or integrate applications that require the ability to define relationships between individual parties and accounts and determine which accounts an individual party can access.

**Potential uses:** Apps that provide customized account access or consolidated views of accounts or family finance apps that help young people pursue their financial goals with oversight from trusted adults.

Begin the integration with following services of Collections domain in API Explorer:
* [Action Entry](../api/?type=post&path=/collections/v1/actionEntry)
* [Add Action Entry](../api/?type=post&path=/collections/v1/addActionEntry)
* [Collection Queues](../api/?type=post&path=/collections/v1/collectionQueues)
* [Collection History](../api/?type=post&path=/collections/v1/collectionHistory)
* [Collection Queue Total](../api/?type=post&path=/collections/v1/collectionQueueTotal)
* [Collection Queue](../api/?type=post&path=/collections/v1/collectionQueue)
* [Mc Fee Collection Outgoing](../api/?type=post&path=/adjustments/v2/mcFeeCollectionOutgoing)
* [Add IRS 21099c Form](../api/?type=post&path=/collections/v1/addIrs21099cForm)

## See Also
- [Cards Accounts Management / Payments](?path=docs/domain/bian/operationsExecution/cardsAccountsManagementPayments.md "Click to open")
- [Channels Digital](?path=docs/domain/bian/operationsExecution/channelsDigital.md "Click to open")
- [Customer Management](?path=docs/domain/bian/operationsExecution/customerManagement.md "Click to open")
- [Loyalty Programs](?path=docs/domain/bian/operationsExecution/loyaltyPrograms.md "Click to open")
- [Installment Loans](?path=docs/domain/bian/operationsExecution/installmentLoans.md "Click to open")
- [Servicing](?path=docs/domain/bian/operationsExecution/servicing.md "Click to open")
- [Transaction Processing](?path=docs/domain/bian/operationsExecution/transactionProcessing.md "Click to open")