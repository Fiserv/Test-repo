# Cards Accounts Management / Payments

Processing and management of card accounts and payment services, such as ACH, check processing, payment receipt & posting, fees, etc.

**Who is it for:** Developers creating or integrating apps that need to tap into information about the financial institution accountholders’ statements and transaction activity that reside on the Fiserv Optis platform.

**How is it used:** Employ these APIs to retrieve transactions residing on cardholders’ statements as well as upcoming cycle to date activity.

**Potential uses:** Apps that provide a mobile or browser experience for customers to view their recent and historical transaction activity.

Begin the integration with following services within the Cards Accounts Management/Payments domain in API Explorer:

<!-- 
type: tab 
titles: Popular Services, Others
-->
* [Card Authorization](../api/?type=post&path=/authorizations/v2/cardAuth)
* [All Statement Activity](../api/?type=post&path=/statements/v2/dtl)
* [Transactions](../api/?type=post&path=/statements/v2/transactions)
* [Cardholder Statement History](../api/?type=post&path=/statements/v2/cardholderStatementHistory)
* [List](../api/?type=post&path=/statements/v2/list)
* [Outstanding Authorizations](../api/?type=post&path=/authorizations/v2/outstandingAuthorizations)
* [Promotions](../api/?type=post&path=/account/v4/promotions)
* [Summary List](../api/?type=post&path=/statements/v2/summaryList)
* [Cycle To Date Activity](../api/?type=post&path=/statements/v2/cycleDtl)
* [Get Payment Due Days](../api/?type=post&path=/customer/v4/getPaymentDueDays)
* [Address History](../api/?type=post&path=/customer/v4/addressHistory)
* [Auth History](../api/?type=post&path=/authorizations/v2/authHistory)
* [Collection Status](../api/?type=post&path=/collections/v1/collectionStatus)
* [Summary](../api/?type=post&path=/statements/v2/summary)
* [Account Auth Strategy Detail](../api/?type=post&path=/commercialcard/v1/accountAuthStrategyDetail)
* [Country Club Invoice](../api/?type=post&path=/statements/v2/countryClubInvoice)
* [Current Statement Activity](../api/?type=post&path=/statements/v2/currentDtl)
* [Merchant Account Information](../api/?type=post&path=/account/v4/merchantAccountInformation)
* [Current Strategy Update](../api/?type=post&path=/debit/v1/currentStrategyUpdate)
* [EMV Chip Details](../api/?type=post&path=/account/v4/emvChipDetails)
* [Override Declined Authorization](../api/?type=post&path=/authorizations/v2/overrideDeclinedAuthorization)
* [Override Declined Cash Authorizations](../api/?type=post&path=/authorizations/v2/overrideDeclinedCashAuthorizations)
* [Method](../api/?type=post&path=/payments/v2/method)
* [Initiate Demand Ach Payment](../api/?type=post&path=/payments/v2/initiateDemandAchPayment)
* [Past DTL](../api/?type=post&path=/statements/v2/pastDtl)
* [Previous DTL](../api/?type=post&path=/statements/v2/previousDtl)
* [MC Charge Back Outgoing](../api/?type=post&path=/adjustments/v2/mcChargeBackOutgoing)
* [Audit History](../api/?type=post&path=/account/v4/auditHistory)
* [Company Auth Details](../api/?type=post&path=/commercialcard/v1/companyAuthDetails)

<!-- type: tab -->

* [Override Declined Merchandise Authorizations](../api/?type=post&path=/authorizations/v2/overrideDeclinedMerchandiseAuthorizations)
* [Stop Payment Details](../api/?type=post&path=/payments/v2/stopPaymentDetails)
* [Update Float Payment](../api/?type=post&path=/payments/v2/updateFloatPayment)
* [Account Spending Limit Detail](../api/?type=post&path=/commercialcard/v1/accountSpendingLimitDetail)
* [Add Account Auth Strategy](../api/?type=post&path=/commercialcard/v1/addAccountAuthStrategy)
* [Update Account Auth Strategy](../api/?type=post&path=/commercialcard/v1/updateAccountAuthStrategy)
* [Script History](../api/?type=post&path=/account/v4/scriptHistory)
* [Account Auth Strategy Delete](../api/?type=post&path=/commercialcard/v1/accountAuthStrategyDelete)
* [Currency Conversion](../api/?type=post&path=/payments/v2/currencyConversion)
* [Account Change In Terms Audit](../api/?type=post&path=/account/v4/accountChangeInTermsAudit)
* [ACS Authorization Controls](../api/?type=post&path=/authorizations/v2/acsAuthorizationControls)
* [Auth Transaction Info](../api/?type=post&path=/authorizations/v2/authTransactionInfo)
* [Stop Payment](../api/?type=post&path=/authorizations/v2/stopPayment)
* [Company Declined Auths](../api/?type=post&path=/commercialcard/v1/companyDeclinedAuths)

<!-- type: tab-end -->

## See Also
- [Channels Digital](?path=docs/domain/bian/operationsExecution/channelsDigital.md "Click to open")
- [Collections](?path=docs/domain/bian/operationsExecution/collections.md "Click to open")
- [Customer Management](?path=docs/domain/bian/operationsExecution/customerManagement.md "Click to open")
- [Installment Loans](?path=docs/domain/bian/operationsExecution/installmentLoans.md "Click to open")
- [Loyalty Programs](?path=docs/domain/bian/operationsExecution/loyaltyPrograms.md "Click to open")
- [Servicing](?path=docs/domain/bian/operationsExecution/servicing.md "Click to open")
- [Transaction Processing](?path=docs/domain/bian/operationsExecution/transactionProcessing.md "Click to open")