# Installment Loans

Managing loans extended to cardholders.

**Who is it for:** Developers creating or integrating apps that need to tap into information about the financial institution accountholders that resides on Fiserv core account processing platforms.

**How is it used:** Employ these APIs to create or integrate applications that require the ability to define relationships between individual parties and accounts and determine which accounts an individual party can access.

**Potential uses:** Apps that provide customized account access or consolidated views of accounts or family finance apps that help young people pursue their financial goals with oversight from trusted adults.

Begin the integration with following services of the Installment Loans domain in API Explorer:
* [Loan Down Payment Amount](../api/?type=post&path=/nonmonetary/v1/loanDownPaymentAmount)
* [Loan Original Purchase Amount](../api/?type=post&path=/nonmonetary/v1/loanOriginalPurchaseAmount)
* [Loan Actual Amount](../api/?type=post&path=/nonmonetary/v1/loanActualAmount)

## See Also
- [Cards Accounts Management / Payments](?path=docs/domain/bian/operationsExecution/cardsAccountsManagementPayments.md "Click to open")
- [Channels Digital](?path=docs/domain/bian/operationsExecution/channelsDigital.md "Click to open")
- [Collections](?path=docs/domain/bian/operationsExecution/collections.md "Click to open")
- [Customer Management](?path=docs/domain/bian/operationsExecution/customerManagement.md "Click to open")
- [Loyalty Programs](?path=docs/domain/bian/operationsExecution/loyaltyPrograms.md "Click to open")
- [Servicing](?path=docs/domain/bian/operationsExecution/servicing.md "Click to open")
- [Transaction Processing](?path=docs/domain/bian/operationsExecution/transactionProcessing.md "Click to open")