# Transaction Processing

Processing of cardholder initiated payments on their outstanding balances.

**Who is it for:** Developers creating or integrating apps that need to process a payment request on behalf of a customer.

**How is it used:** Employ these APIs to process and retrieve payment information applied to customers’ accounts.

**Potential uses:** Apps that provide a customer with a mobile or browser experience to provide a payment request to the Optis system.

Begin the integration with following services of Transaction Processing domain in API Explorer:

* [Right Time Payment](../api/?type=post&path=/payments/rightTimePayment)
* [Get Payment Due Dates](../api/?type=post&path=/ui/getPaymentDueDates)
* [Payment History](../api/?type=post&path=/payments/paymentHistory)
* [Payment Float Summary](../api/?type=post&path=/payments/paymentFloatSummary)
* [Adjustment Transaction](../api/?type=post&path=/maintenance/adjustmentTransaction)
* [Auto Payments](../api/?type=post&path=/payments/autoPayments)
* [Reverse Right Time Payment](../api/?type=post&path=/payments/reverseRightTimePayment)
* [Payment Details](../api/?type=post&path=/payments/paymentDetails)
* [Expanded Payoff Balance With Grace](../api/?type=post&path=/account/expandedPayoffBalanceWithGrace)
* [Add Batch Adjustment](../api/?type=post&path=/adjustments/addBatchAdjustment)
* [Payoff Balance](../api/?type=post&path=/account/payoffBalance)
* [Expanded Payoff Balance](../api/?type=post&path=/account/expandedPayoffBalance)
* [Clear Payment](../api/?type=post&path=/payments/clearPayment)
* [Approved Queue](../api/?type=post&path=/adjustments/approvedQueue)
* [Rejected Queue](../api/?type=post&path=/adjustments/rejectedQueue)
* [Delete Batch Adjustment](../api/?type=post&path=/adjustments/deleteBatchAdjustment)
* [Pending Queue](../api/?type=post&path=/adjustments/pendingQueue)
* [Add Dual Adjustment](../api/?type=post&path=/adjustments/addDualAdjustment)
* [Approve Adjustment](../api/?type=post&path=/adjustments/approveAdjustment)
* [Delete Adjustment](../api/?type=post&path=/adjustments/deleteAdjustment)
* [Fee Adjustment Reversal](../api/?type=post&path=/adjustments/feeAdjustmentReversal)
* [Reject Adjustment](../api/?type=post&path=/adjustments/rejectAdjustment)
* [Minimum Payment Due](../api/?type=post&path=/payments/minimumPaymentDue)

## See Also
- [Cards Accounts Management / Payments](?path=docs/domain/bian/operationsExecution/cardsAccountsManagementPayments.md "Click to open")
- [Channels Digital](?path=docs/domain/bian/operationsExecution/channelsDigital.md "Click to open")
- [Collections](?path=docs/domain/bian/operationsExecution/collections.md "Click to open")
- [Customer Management](?path=docs/domain/bian/operationsExecution/customerManagement.md "Click to open")
- [Installment Loans](?path=docs/domain/bian/operationsExecution/installmentLoans.md "Click to open")
- [Loyalty Programs](?path=docs/domain/bian/operationsExecution/loyaltyPrograms.md "Click to open")
- [Servicing](?path=docs/domain/bian/operationsExecution/servicing.md "Click to open")