# Data Management

Establishment of controls that govern processing of a payment instrument.

**Who is it for:** Developers creating administrative functions for authorization approvals, credential management, alerts & controls and parameter settings.

**How is it used:** Employ these APIs to create, modify or remove payment instrument management settings on the processing platform.

**Potential uses:** Apps that are not customer-facing, but are responsible for management of the card platform.

Begin the integration with following services of External Agencies domain in API Explorer:

<!-- 
type: tab 
titles: Popular Services, Others
-->
* [Data Link Cardholder Values](../api/?type=post&path=/account/v4/dataLinkCardholderValues)
* [Consumer Preference Add](../api/?type=post&path=/consumerPreferences/v1/consumerPreferenceAdd)
* [Consumer Preference Delete](../api/?type=post&path=/consumerPreferences/v1/consumerPreferenceDelete)
* [Consumer Preference Detail](../api/?type=post&path=/consumerPreferences/v1/consumerPreferenceDetail)
* [Consumer Preference List](../api/?type=post&path=/consumerPreferences/v1/consumerPreferenceList)
* [Consumer Preference Update](../api/?type=post&path=/consumerPreferences/v1/consumerPreferenceUpdate)
* [Consumer Registration Add](../api/?type=post&path=/consumerPreferences/v1/consumerRegistrationAdd)
* [Consumer Registration Update](../api/?type=post&path=/consumerPreferences/v1/consumerRegistrationUpdate)
* [Suspend Strategy](../api/?type=post&path=/debit/v1/suspendStrategy)
* [Suspend Strategy Add](../api/?type=post&path=/debit/v1/suspendStrategyAdd)
* [Data Link Cardholder Values Update](../api/?type=post&path=/maintenance/v2/dataLinkCardholderValuesUpdate)
* [Credit Limit Control Shell Add](../api/?type=post&path=/ocs/v1/creditLimitControlShellAdd)
* [Credit Limit Control Shell Delete](../api/?type=post&path=/ocs/v1/creditLimitControlShellDelete)
* [Credit Operator Code Display](../api/?type=post&path=/ocs/v1/creditOperatorCodeDisplay)
* [Shell Add](../api/?type=post&path=/ocs/v1/shellAdd)
* [Shell Delete](../api/?type=post&path=/ocs/v1/shellDelete)
* [Shell Enable](../api/?type=post&path=/ocs/v1/shellEnable)
* [Shell Password Reset](../api/?type=post&path=/ocs/v1/shellPasswordReset)
* [Shell Update](../api/?type=post&path=/ocs/v1/shellUpdate)
* [Shell View](../api/?type=post&path=/ocs/v1/shellView)
* [Cycle Schedule](../api/?type=post&path=/statements/v2/cycleSchedule)
* [Consumer Preference Alerts Fields](../api/?type=post&path=/utilities/v4/consumerPreferenceAlertsFields)
* [Consumer Preference Controls Fields](../api/?type=post&path=/utilities/v4/consumerPreferenceControlsFields)
* [PCF Controls](../api/?type=post&path=/utilities/v4/pcfControls)
* [PCF Method Override](../api/?type=post&path=/utilities/v4/pcfMethodOverride)
* [Table Access](../api/?type=post&path=/utilities/v4/tableAccess)

<!-- type: tab -->

* [Suspend Strategy Release](../api/?type=post&path=/debit/v1/suspendStrategyRelease)
* [Suspend Strategy Update](../api/?type=post&path=/debit/v1/suspendStrategyUpdate)
* [Data Link Aggregator Update](../api/?type=post&path=/maintenance/v2/dataLinkAggregatorUpdate)
* [Automated Adjustment Profile](../api/?type=post&path=/ocs/v1/automatedAdjustmentProfile)
* [Credit Limit Control Shell Copy](../api/?type=post&path=/ocs/v1/creditLimitControlShellCopy)
* [Credit Limit Control Shell Detail](../api/?type=post&path=/ocs/v1/creditLimitControlShellDetail)
* [Credit Limit Control Shell List](../api/?type=post&path=/ocs/v1/creditLimitControlShellList)
* [Credit Limit Control Shell Profile Add](../api/?type=post&path=/ocs/v1/creditLimitControlShellProfileAdd)
* [Credit Limit Control Shell Profile Delete](../api/?type=post&path=/ocs/v1/creditLimitControlShellProfileDelete)
* [Credit Limit Control Shell Profile Update](../api/?type=post&path=/ocs/v1/creditLimitControlShellProfileUpdate)
* [Consumer Accounts](../api/?type=post&path=/utilities/v4/consumerAccounts)
* [PCF Read Or Update](../api/?type=post&path=/utilities/v4/pcfReadOrUpdate)
* [Issuer Defined Pricing Control Code 19](../api/?type=post&path=/nonmonetary/v1/issuerDefinedPricingControlCode19)
* [Issuer Defined Pricing Control Code 20](../api/?type=post&path=/nonmonetary/v1/issuerDefinedPricingControlCode20)

## See Also
- [Operational Services / Document Management](?path=docs/domain/bian/businessSupport/operationalServicesDocumentManagement.md "Click to open")