# Operational Services / Document Management

Creation of cardholder communications documents (letters).

**Who is it for:** Developers creating letter management functions.

**How is it used:** Employ these APIs to generate letter requests bound for customers as well as review.

**Potential uses:** Apps that create or manage letter requests on behalf of Financial Institutions.

Begin the integration with following services of Operational Services/Document Management domain in API Explorer:
* [Correspondence Reprint Request](../api/?type=post&path=/maintenance/v2/correspondenceReprintRequest)
* [Generate Letter](../api/?type=post&path=/maintenance/v2/generateLetter)
* [Letter Captions](../api/?type=post&path=/maintenance/v2/letterCaptions)
* [Letter Pending](../api/?type=post&path=/statements/v2/letterPending)
* [Letter Definition Detail](../api/?type=post&path=/statements/v2/letterDefinitionDetail)
* [Correspondence Summary](../api/?type=post&path=/statements/v2/correspondenceSummary)

## See Also
- [Data Management](?path=docs/domain/bian/businessSupport/dataManagement.md "Click to open")