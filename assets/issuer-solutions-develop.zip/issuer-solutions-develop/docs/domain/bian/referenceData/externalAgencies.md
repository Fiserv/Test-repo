# External Agencies

Review and modification of credit bureau reporting.

**Who is it for:** Developers who need scored models evaluating a customer’s credit history.

**How is it used:** Employee these APIs to tap into credit bureau reports and on-demand updates of credit bureau scores.

**Potential uses:** Apps that need to evaluate a customer’s current credit worthiness.

Begin the integration with following services of External Agencies domain in API Explorer:
* [Report Status](../api/?type=post&path=/creditBureau/v1/reportStatus)
* [Information](../api/?type=post&path=/creditBureau/v1/information)
* [Company Bureau Setting](../api/?type=post&path=/commercialcard/v1/companyBureauSetting)
* [Company Bureau](../api/?type=post&path=/creditBureau/v1/companyBureau)
* [Company Bureau Detail](../api/?type=post&path=/creditBureau/v1/companyBureauDetail)
* [Bankruptcy Information Update](../api/?type=post&path=/creditBureau/v1/bankruptcyInformationUpdate)
* [Company Bureau Update](../api/?type=post&path=/creditBureau/v1/companyBureauUpdate)
* [Company Bureau Detail Add](../api/?type=post&path=/creditBureau/v1/companyBureauDetailAdd)
* [Company Bureau Detail Update](../api/?type=post&path=/creditBureau/v1/companyBureauDetailUpdate)
* [Company Bureau Report Status](../api/?type=post&path=/commercialcard/v1/companyBureauReportStatus)
* [Company Bureau Detail Delete](../api/?type=post&path=/creditBureau/v1/companyBureauDetailDelete)
* [Bankruptcy Information](../api/?type=post&path=/creditBureau/v1/bankruptcyInformation)
* [Ticket Visa Data](../api/?type=post&path=/transactions/v2/ticketVisaData)
* [Ticket Mastercard Data](../api/?type=post&path=/transactions/v2/ticketMastercardData)
* [Visa Warning Bulletin Status](../api/?type=post&path=/maintenance/v2/visaWarningBulletinStatus)
* [Mastercard Warning Bulletin Status](../api/?type=post&path=/maintenance/v2/masterCardWarningBulletinStatus)
* [Visa Issuer Account Updater](../api/?type=post&path=/maintenance/v2/visaIssuerAccountUpdater)
* [Visa Fee Recovery](../api/?type=post&path=/maintenance/v2/visaFeeRecovery)
* [Amex Card Security Detail](../api/?type=post&path=/authorizations/v2/amexCardSecurityDetail)
* [Visa Processing Errors](../api/?type=post&path=/adjustments/v2/visaProcessingErrors)
* [BI](../api/?type=post&path=/creditBureau/v1/bi)
* [MC Issuer Account Update](../api/?type=post&path=/disputes/v2/mcIssuerAccountUpdate)
* [Balance Consolidation Detail](../api/?type=post&path=/transactions/v2/balanceConsolidationDetail)
* [Amex Charge Back Outgoing](../api/?type=post&path=/adjustments/v2/amexChargeBackOutgoing)
* [Visa Authorization Issues](../api/?type=post&path=/adjustments/v2/visaAuthorizationIssues)
* [Visa Cancellations And Returns](../api/?type=post&path=/adjustments/v2/visaCancellationsAndReturns)
* [Visa Fraud Issues](../api/?type=post&path=/adjustments/v2/visaFraudIssues)
* [Visa Non Receipt Goods Services](../api/?type=post&path=/adjustments/v2/visaNonReceiptGoodsServices)
* [Visa Non Receipt Information](../api/?type=post&path=/adjustments/v2/visaNonReceiptInformation)
