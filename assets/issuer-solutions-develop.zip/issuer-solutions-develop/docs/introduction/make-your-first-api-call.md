# Make Your First API Call

This section describes the process to send an API request to the server and receive a response payload. To test the APIs, use the built-in API Explorer in Fiserv Developer Studio or any third-party API testing tool.


## Using the Built-in API Explorer

To test our APIs in Sandbox environment, no API Keys or Access Token is required. The advanced Developer Studio of Fiserv is connected to our Sandbox environment that lets you test the APIs you want without configuring your system or installing any tool, this Sandbox is our mock server to simulate the request/response for our API.

To test an API, do the following:
1. From API Explorer, click the API you want to test 
2. Select the Api to be tested
3. See the detail of all the values considered in the **Request Schema** tab
4. Click **Run**. 
5. Response payload of API request displays under the **Response** tab.

<kbd>
  <img src="https://user-images.githubusercontent.com/81968767/145146944-6285dfe4-898a-4b9c-bda4-d351a6a9568f.gif" alt="API Explorer" />
</kbd> <br><br>

<!-- theme: success -->
> #### Tip
> 
> Sample API request payloads are added under the drop-down, and you can select the drop-down options to view the response for such requests.

