# Before You Start
<!-- theme: info -->
> #### Note for Developers 
>
> The current user journey enables developers to access a range of Standard Bank Platform APIs on Merchant. We continue to refine the API content on Merchant with the goal of showing clearly how our Merchant APIs facilitate integration to each of our banking solutions.  <br> <br> We are working on developing a registered user journey. Once registration is enabled on Developer Studio, you can sign up to obtain credentials along with the instructions to integrate Merchant APIs with our banking platforms.


Register to the Fiserv Developer Studio to test the APIs in test and live environments. However, registration is not required to learn about our API integration process and test the APIs in API Explorer.

## Register to Fiserv Developer Studio
To validate and deploy Fiserv banking APIs into production, create an account with Fiserv Developer Studio to obtain credentials for sandbox testing and live environments.


### Setting up an Account
<!-- theme: info -->
> #### Note
>
> Registration to Fiserv Developer Studio is not enabled yet.

To set up an account on Fiserv Developer Studio, follow the steps below:
1.	From the top-right corner of the screen, click **Create Account**
2.	Populate the required fields and click **Next**
3.	Follow the instructions on the screen to set up your account based on integration requirements
4.	Sign on to your Fiserv Developer Studio account once it is activated


After successful registration, following credentials are sent via email:
- API Key
- Username/Password
- OrgId 
- AppId
- VendorId 
- ChannelId

Some of these credentials are required to send as header parameters under the EFXHeader parameter.
## Know Our Standard API structure 

This section describes a standard structure of request and response message of Merchant RESTful APIs. 

### Request Message

All API requests must contain the following components:

*	API Method: POST or PUT
*   Host URL:  https://{_url_}/v{_version_}/
*	Request Header
*	Request Body

For every API request, a response message is obtained that contains a response payload and status of the API request.

#### Request Body
Request body of an API that changes based on the type of transaction being processed. Request body contains the detailed information that is required to perform a particular transaction.

**Request Payload:** 

Following example shows the sample request payload for **merchantBlockCriteria** API request.

```
{
  "common": {
    "user": "string",
    "agent": "4000",
    "cycle": "T",
    "clientNumber": "1000",
    "system": "2000",
    "prin": "3000",
    "debug": true,
    "org": "string",
    "processor": true,
    "contentType": "string",
    "retry": 0,
    "timeout": 45000,
    "siteId": "4201",
    "externalCustomerId": "string",
    "accountId": "8888888888888888",
    "presentationId": "string"
  },
  "selectFields": ["anyvalidfieldname1","anyvalidfieldname2","anyvalidfieldname3","anyvalidfieldname?","anyvalidfieldname?n"],
  "odsNaming": true,
  "startSequence": "1",
  "endSequence": "25",
  "clientIdentifier": "string",
  "systemIdentifier": "string",
  "principalIdentifier": "string"
}
```


### Response Message


Upon a successful API request, a response payload is received. The response payload contains the status and the returned details of the requested API in key-value pairs. The default response format is JSON (JavaScript Object Notation). 


**Response Payload:**

Following example shows the sample response payload for **merchantBlockCriteria** API request.

```
{
  "processorInfo": {
    "system": "string",
    "cycle": "string",
    "tor": "string",
    "mode": "string"
  },
  "merchantBlockCriteriaFields": [
    {
      "clientIdentifier": "string",
      "systemIdentifier": "string",
      "principalIdentifier": "string",
      "terminalIdentifier": "string",
      "operatorCode": "string",
      "declineRate": "string",
      "timeLimit": "string",
      "declineReasonCode": "string",
      "expandedDeclineReasonCode": "string",
      "uniqueAccountCount": "string",
      "minimumThresholdAmount": "string",
      "authTypeCode": "string",
      "declineDuration": "string"
    }
  ]
}
```

To view the API documentation of **merchantBlockCriteria** API in API Explorer, [click here.](../api/?type=post&path=/merchant/v1/merchantBlockCriteria)
   
