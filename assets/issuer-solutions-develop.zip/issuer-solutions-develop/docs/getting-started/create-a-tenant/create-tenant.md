# Create a tenant

## Documentation Quickstart Guide

This section explains how you can code your own tenant in the language of your choice.  The only thing you must do is adhere to the `Tenant API specification`, which can be seen [here](../api/?type=get&path=/v1/docs)

## Template code

## Implementation

....


## Next steps

