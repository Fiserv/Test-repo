# Create a tenant

## Documentation Quickstart Guide

This section explains how you can code your own tenant in the language of your choice.  The only thing you must do is adhere to the `Tenant API specification`, which can be see [here](../api/?type=get&path=/v1/docs)

## Template code

## Implementation

....

___

## Next steps 

[Setup Tenant]


Need Help ?
[FAQ]

[//]: # (These are reference links used in markdown file)

[FAQ]: <?path=docs/faq/faq.md>

[Setup Tenant]: <?path=docs/getting-started/setup-tenant/setup-tenant.md>