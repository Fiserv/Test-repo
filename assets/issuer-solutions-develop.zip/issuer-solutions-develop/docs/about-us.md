# About us

### Take Your Imagination To Market

Fiserv offers hundreds of RESTful APIs that span the gamut of payment industry functionality.  Clients can create customized representations of their product offerings by taking advantage of the breadth of coverage of Fiserv’s APIs.  Functions supporting Customer Service, Collections, Risk Management and other business areas are readily available for consumption within a client’s own mobile, desktop or browser-based applications.

## The Fiserv Difference

### Streamline & Simplify

<img src="https://fiapi.firstdata.com/portal/assets/images/simplify_icon_D.png" width="50%" alt="Streamline and Simplify">

Fiserv’s API Developer Studio exposes a world of possibility for real-time data exchanges with the Optis platform.  Fiserv offers solutions to fit every card industry need.  Fiserv’s interoperable API portal is a catalyst for application development with API categorizations, search functionality with aoto-complete entries, standardized naming conventions and a functional Sandbox for prospective clients.

### Form & Function

<img src="https://fiapi.firstdata.com/portal/assets/images/laptop_mockup_D.png" width="80%" alt="Form and Function">

Developers and Business Analysts can easily explore a range of features:

* APIs by section and by name
* Optis functions by name (using Fiserv’s Optis Open Data Streams platform)
* Model Views
* Request/Response Payload Format & Syntax Data


### A Fresh Take

<img src="https://fiapi.firstdata.com/portal/assets/images/Fresh_Take.png" width="70%" alt="Fresh Take">

Fiserv's financial services platform delivers solutions in:

* Financial Institution and retail credit card issuing (both Credit and Debit)
* Commercial card processing, management, payment and cash management

All working to help drive efficiency, reduce risk, improve portfolio management and halt attrition.

